# Copyright © 2022 mightyK1ngRichard <dimapermyakov55@gmail.com>

def main():
    pass


if __name__ == '__main__':
    main()
