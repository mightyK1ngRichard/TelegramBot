# Laboratory work #6.
<img src="https://img.shields.io/github/license/DimaPermyakov/IU5?color=brightgreen" alt="MIT License"> <img src="https://img.shields.io/badge/language-Python-green.svg" alt="Python Language">

## About bot:
This bot has was been written on the aiogram module. All data storage in sql-tables.

The main purpose of the bot: to meet students to each other.

Welcome to the bot: https://t.me/BMSTUstudentsBOT

## Code Locations:
1. [The code of the laboratory work.](https://github.com/IU5-IT/IU5-IT/blob/master/Term-3/BKIT-2022/03-lab-06-DimaPermyakov/main.py)
2. [The report of the laboratory work.](#)


## [Conditions of the laboratory work.](https://github.com/ugapanyuk/BKIT_2021/wiki/lab_bot2)


## Preview:
![photo](data/screens/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202022-11-07%20%D0%B2%2013.00.17.png)
